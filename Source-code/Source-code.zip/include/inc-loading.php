<div id="preloader">
	<div id="status">
        <div class="preloader-logo"></div>
        <h3 class="center-text">Xin chào</h3>
        <p class="center-text smaller-text">
            Chúng tôi đang tải nội dung ! Xin chờ trong giây lát !
        </p>
    </div>
</div>