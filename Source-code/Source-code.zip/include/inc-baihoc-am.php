<script>
function triggerAudio(abc) {
    var playid = abc.id.substring(4);
    document.getElementById("audio"+playid).play();
}
</script>

<?php
	$idBaiHoc = $_GET["bh"];
	$idLoaiBaiHoc = $_GET["lbh"];
	$sql = "select * from am where a_BaiHoc = $idBaiHoc";
	$result = DataProvider::GetRows($sql);
	foreach ($result as $value) 
			{
				?>
				<div class="container switch-box">
                    <h4><?php echo '<img src="'.$value[1].'"/>'?></h4>
                    <a href="#" class="switch-icon">
					<p id="play<?php echo $value[0];?>" onclick="triggerAudio(this)"><img style="width: 50px;height: 50px;" src="images\loa.png"/></p> 
                    </a>
                </div>
				
				<audio id="audio<?php echo $value[0];?>">
					<source src="<?php echo $value[2];?>" type="audio/mpeg" />
				</audio>
              
              <div>
              	   <div style="float:left">
                   		<p style="margin:0px;" id="play<?php echo "h1".$value[0];?>" onclick="triggerAudio(this)"><img src="<?php echo $value[3];?>"/></p> 
                        <p style="text-align:center; font-weight:bold"><?php echo $value[4] ?></p>
                        <audio id="audio<?php echo "h1".$value[0];?>">
							<source src="<?php echo $value[5];?>" type="audio/mpeg" />
						</audio>
                   </div>
              	   <div style="float:left">
                   		<p style="margin:0px;" id="play<?php echo "h2".$value[0];?>" onclick="triggerAudio(this)"><img src="<?php echo $value[6];?>"/></p> 
                         <p style="text-align:center; font-weight:bold"><?php echo $value[7] ?></p>
                        <audio id="audio<?php echo "h2".$value[0];?>">
							<source src="<?php echo $value[8];?>" type="audio/mpeg" />
						</audio>
                   </div>
                   <div style="float:left">
                   		<p style="margin:0px;" id="play<?php echo "h2".$value[0];?>" onclick="triggerAudio(this)"><img src="<?php echo $value[9];?>"/></p> 
                        <p style="text-align:center; font-weight:bold"><?php echo $value[10] ?></p>
                        <audio id="audio<?php echo "h2".$value[0];?>">
							<source src="<?php echo $value[11];?>" type="audio/mpeg" />
						</audio>
                   </div>
              </div>
			<?php
			}
?>